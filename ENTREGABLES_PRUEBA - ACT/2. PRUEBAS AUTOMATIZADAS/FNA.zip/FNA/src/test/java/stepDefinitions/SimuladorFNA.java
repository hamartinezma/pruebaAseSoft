/*
Autor: Alexander Martínez
Fecha: 27/02/2020
Ver. 1.0
*/
package stepDefinitions; 

import java.awt.Desktop.Action;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import cucumber.api.java.After;
import cucumber.api.java.en.And;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import modules.Screenshot;
import org.openqa.selenium.support.ui.Select;

public class SimuladorFNA { 
   WebDriver driver = null;
   @Given("^Que tengo que cargar la pagina: https://www.fna.gov.co:8099/SimuladorUI/#/$")
   public void openPage() { 

	   System.setProperty("webdriver.chrome.driver",   Thread.currentThread().getContextClassLoader().getResource("drivers/chromedriver.exe").getFile());  
	 //chromeOptions.setBinary("D:\\Program Files\\Google\\GoogleChromePortableBeta\\GoogleChromePortable.exe"); /*Ubica mi portable*/
	 //System.setProperty("webdriver.chrome.driver", "C://chromedriver.exe");
	   ChromeOptions options = new ChromeOptions();
	   options.addArguments("start-maximized"); // abro el navegador en modo maximizado  
	   options.addArguments("disable-infobars"); // desabilito infobars (si los hay)
	   options.addArguments("--disable-extensions"); // desabilito extensiones
	   options.addArguments("--disable-gpu"); // modo que aplica solo para Windows
	   options.addArguments("--disable-dev-shm-usage"); // libero consumo de recursos
	   options.addArguments("--no-sandbox"); // modo para omitir seguridad del navegador
       driver = new ChromeDriver(); //Driver para cargar el browser para este caso Chrome
       
	   driver.get("https://www.fna.gov.co:8099/SimuladorUI/#/"); //Cargo la página
	   driver.manage().window().maximize(); //La dejo maximizada
	   driver.getTitle();       
   } 
   
   
   @When("^seleccione como quiero solicitar mi credito$")
   public void tipoSolicitud() { 
       WebElement IND = driver.findElement(By.id("IND"));
       WebElement Continuar = driver.findElement(By.xpath("//*[@id=\"step-1\"]/div[3]/div/div/div/button"));
     
       if(IND.isDisplayed()) {
       	System.out.println("Check  button IND : displayed");
       	IND.click();
       	Continuar.click();
       }
       else {
       	System.out.println("Check  button IND : notDisplayed");
       }
   } 
   
   @And("^seleccione mi tipo de vinculacion$")
   public void infoAfiliado() { 
	   Select tipoVinculacionAfiliado1 = new Select(driver.findElement(By.id("tipoVinculacionAfiliado1")));
	   tipoVinculacionAfiliado1.selectByIndex(1);
	   WebElement Continuar = driver.findElement(By.xpath("//*[@id=\"step-2\"]/div/div/div[2]/div[2]/button"));
	   Continuar.click();
   }
   
   @And("^especifique mis ingresos y egresos$")
   public void infoIngresosEgresos() {
	   driver.findElement(By.id("ingresoBasicoAfiliado1")).clear();
	   driver.findElement(By.id("ingresoBasicoAfiliado1")).sendKeys("1000000");
	   driver.findElement(By.id("ingresoAdicionalAfiliado1")).clear();
	   driver.findElement(By.id("ingresoAdicionalAfiliado1")).sendKeys("1000000");
	   driver.findElement(By.id("egresosAfiliado1")).clear();
	   driver.findElement(By.id("egresosAfiliado1")).sendKeys("500000");
	   WebElement Continuar = driver.findElement(By.xpath("//*[@id=\"step-3\"]/div/div/div[4]/div[2]/button"));
	   Continuar.click();  
   }
   
   @And("^especifique mis condiciones financieras$")
   public void condicionesFinancieras() { 
	   Select destinoCredito = new Select(driver.findElement(By.id("destinoCredito")));
	   destinoCredito.selectByIndex(1);
	   Select subsidio = new Select(driver.findElement(By.id("subsidio")));
	   subsidio.selectByIndex(1);
	   WebElement Simular = driver.findElement(By.xpath("//*[@id=\"step-4\"]/div/div/div[2]/div[2]/button"));
	   Simular.click();
   }
   
   @Then("^visualizo el resultado de la simulacion$")
   public void resultado() throws Exception {
	   WebDriverWait wait = new WebDriverWait(driver, 20);

	   WebElement titleSimulacion = driver.findElement(By.xpath("//*[@id=\"step-5\"]/div/h5[1]")); ;
	   wait.until(ExpectedConditions.elementToBeClickable(titleSimulacion));
	   Object message = titleSimulacion.isDisplayed() ? "Check title simulacion: OK" : "Check title simulacion: FAIL";
       System.out.println(message);
	   Screenshot.takeSnapShot(driver, "D://resultado.png") ; //Capturo la evidencia
   } 
      
   
   @After
   public void tearDown() throws InterruptedException
   {
	 driver.close(); /*Bingo llegó :D*/
   }
   
   
   
   
   
}

